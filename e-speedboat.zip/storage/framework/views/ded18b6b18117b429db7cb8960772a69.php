<?php $__env->startSection('title', 'Pemesanan Speedboat'); ?>

<?php $__env->startSection('content'); ?>
    <div class="app-content"> <!--begin::Container-->
        <div class="container-fluid"> <!--begin::Row-->
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pemesanan.pemesanan-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-3706382937-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-speedboat\resources\views/pemesanan/pemesanan.blade.php ENDPATH**/ ?>