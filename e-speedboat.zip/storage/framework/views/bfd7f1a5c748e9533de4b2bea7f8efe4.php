<?php $__env->startSection('title', 'Pemesanan'); ?>

<?php $__env->startSection('content'); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('hp.pemesanan-table');

$__html = app('livewire')->mount($__name, $__params, 'lw-2259100900-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('hp.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-speedboat\resources\views/hp/pemesanan/pemesanan.blade.php ENDPATH**/ ?>