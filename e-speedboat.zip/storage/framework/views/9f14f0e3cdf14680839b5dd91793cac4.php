<div>
    <!-- Modal Tambah-->
    <div class="modal" id="tambahModal" tabindex="-1" aria-labelledby="tambahModalLabel1" aria-hidden="true"
        style="display: <?php echo e($isOpen ? 'block' : 'none'); ?>;">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="tambahModalLabel1">
                        <h4><?php echo e($selectedId ? 'Ubah' : 'Tambah'); ?> Penumpang
                        </h4>
                    </h4>
                    <button wire:click.prevent="resetData()" type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"><span aria-hidden="true"></span></button>

                </div>
                <div class="modal-body">
                    <form>
                        <div class="row">
                            <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
                                <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                                    role="alert">
                                    <?php echo e(session('success')); ?>

                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="nama"><strong>Nama </strong> </label>
                                    <input type="text" class="form-control" wire:model="nama"
                                        placeholder="Masukan Nama Lengkap ">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size:12px;"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div class="mb-3">
                                    <label for="email"><strong>Email</strong> </label>
                                    <input type="email" class="form-control" wire:model="email"
                                        placeholder="Masukan email ">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size:12px;"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div class="mb-3">
                                    <label for="password"><strong>Password</strong> </label>
                                    <input type="password" class="form-control" wire:model="password"
                                        placeholder="Masukan Password ">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size:12px;"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div class="mb-3">
                                    <label for="umur"><strong>Umur</strong> </label>
                                    <input type="text" class="form-control" wire:model="umur"
                                        placeholder="Masukan Umur ">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['umur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size:12px;"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div class="mb-3">
                                    <label for="alamat"><strong>Alamat</strong> </label>
                                    <textarea name="alamat" id="alamat" cols="30" rows="5" class="form-control" wire:model="alamat"
                                        placeholder="Masukan Alamat"></textarea>
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" style="font-size:12px;"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"
                        wire:click.prevent="simpan()"><?php echo e($selectedId ? 'Ubah' : 'Simpan'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">Daftar Penumpang</h3>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#tambahModal" wire:click.prevent="tambah">
                            Tambah
                        </button>
                    </div>
                </div> <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 10px">#</th>
                                <th>Nama</th>
                                <th>Umur</th>
                                <th>Alamat</th>
                                <th>Email</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $penumpang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + $penumpang->firstItem()); ?></td>
                                    <td><?php echo e($pem->nama); ?></td>
                                    <td><?php echo e($pem->umur); ?></td>
                                    <td><?php echo e($pem->alamat); ?></td>
                                    <td><?php echo e($pem->email); ?></td>
                                    <td width="200">
                                        <button data-bs-toggle="modal" data-bs-target="#tambahModal"
                                            class="btn btn-warning" wire:click.prevent="edit('<?php echo e($pem->id); ?>')">
                                            Edit </button>
                                        
                                    </td>
                                </tr>

                                <div id="hapusModal-<?php echo e($pem->id); ?>" class="modal fade" tabindex="-1"
                                    role="dialog" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                Hapus Data
                                            </div>
                                            <div class="modal-body">
                                                <p>Apakah Anda yakin akan menghapus data ini?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button wire:click.prevent="resetData()" type="button"
                                                    class="btn btn-secondary" data-bs-dismiss="modal">
                                                    Batal
                                                </button>
                                                <button data-bs-dismiss="modal" type="button" class="btn btn-danger"
                                                    wire:click.prevent="hapus('<?php echo e($pem->id); ?>')">
                                                    Hapus
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div> <!-- /.card-body -->
                <div class="card-footer clearfix">
                    <?php echo e($penumpang->links()); ?>

                </div>
            </div> <!-- /.card -->
        </div>
    </div>


</div>
<?php /**PATH C:\laragon\www\e-speedboat\resources\views/livewire/penumpang/penumpang-table.blade.php ENDPATH**/ ?>