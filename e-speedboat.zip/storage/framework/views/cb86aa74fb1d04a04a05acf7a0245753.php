<div>
    <div class="container mt-3">
        <div class="card">
            <div class="card-body">
                <!--[if BLOCK]><![endif]--><?php if(session()->has('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <div class="row">
                    <div class="col-sm-8">
                        <div class="mb-3">
                            <input type="date" class="form-control" name="cari_jadwal" id="cari_jadwal"
                                aria-describedby="helpId" placeholder="Cari Jadwal" wire:model="cari_jadwal" />
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary" wire:click.prevent="jadwal">Cari</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--[if BLOCK]><![endif]--><?php if($tampilJadwal): ?>
        <div class="container mt-3">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Nama Speedboat</th>
                                <th>Perjalanan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tampilJadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $jdwl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $penumpang = \App\Models\Booking::where('jadwal_id', $jdwl->id)
                                        ->where('tgl_keberangkatan', $cari_jadwal)
                                        ->count();
                                    $tersedia = $jdwl->speedboat->kapasitas_muatan - $penumpang;
                                ?>
                                <tr>
                                    <td><?php echo e($jdwl->speedboat->nama); ?><br> Tersedia <?php echo e($tersedia); ?> /
                                        <?php echo e($jdwl->speedboat->kapasitas_muatan); ?><br>
                                        <?php echo e($cari_jadwal); ?>

                                    </td>
                                    <td><?php echo e($jdwl->berangkat); ?> - <?php echo e($jdwl->tiba); ?> <br> <?php echo e($jdwl->jam_berangkat); ?>

                                        -<?php echo e($jdwl->jam_tiba); ?>

                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-info"
                                            wire:click.prevent="pesanSpeedboat(<?php echo e($jdwl->id); ?>)">
                                            <?php if(session()->get('jadwal_id') == $jdwl->id): ?>
                                                Dipesan
                                            <?php else: ?>
                                                Pesan
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary" wire:click.prevent="simpan()">Proses
                            Pemesanan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH C:\laragon\www\e-speedboat\resources\views/livewire/hp/pemesanan-table.blade.php ENDPATH**/ ?>