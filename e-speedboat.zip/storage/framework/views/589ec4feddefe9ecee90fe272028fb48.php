<div>
    <div class="container mt-3">
        <div class="card">
            <div class="card-body">
                <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Speedboat</th>
                                <th>Berangkat</th>
                                <th>Tiba</th>
                                <th>Konfirmasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pemesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + $pemesanan->firstItem()); ?></td>
                                    <td><?php echo e($item->jadwal->speedboat->nama); ?><br>
                                        <?php echo e($item->tgl_keberangkatan); ?>


                                    </td>
                                    <td><?php echo e($item->jadwal->berangkat); ?><br>
                                        <?php echo e($item->jadwal->jam_berangkat); ?>

                                    </td>
                                    <td><?php echo e($item->jadwal->tiba); ?><br>
                                        <?php echo e($item->jadwal->jam_tiba); ?>

                                    </td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if(auth()->user()->level == 'penumpang'): ?>
                                            <!--[if BLOCK]><![endif]--><?php if($item->status == 'terima'): ?>
                                                <span class="btn btn-sm btn-success"><?php echo e($item->status); ?></span>
                                            <?php elseif($item->status == 'tolak'): ?>
                                                <span class="btn btn-sm btn-danger"><?php echo e($item->status); ?></span>
                                            <?php else: ?>
                                                <span class="btn btn-sm btn-warning"><?php echo e($item->status); ?></span>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <!--[if BLOCK]><![endif]--><?php if($item->status !== 'terima'): ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                    wire:click.prevent="batal(<?php echo e($item->id); ?>)">Batal</button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php else: ?>
                                            <!--[if BLOCK]><![endif]--><?php if($item->status == 'terima'): ?>
                                                <button class="btn btn-sm btn-success"
                                                    wire:click.prevent="tolak(<?php echo e($item->id); ?>)"> Status
                                                    Diterima</button>
                                            <?php elseif($item->status == 'tolak'): ?>
                                                <button class="btn btn-sm btn-danger"
                                                    wire:click.prevent="terima(<?php echo e($item->id); ?>)"> Status
                                                    Ditolak</button>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-danger"
                                                    wire:click.prevent="tolak(<?php echo e($item->id); ?>)">Tolak</button>
                                                <button class="btn btn-sm btn-primary"
                                                    wire:click.prevent="terima(<?php echo e($item->id); ?>)">Terima</button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                    <?php echo e($pemesanan->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\e-speedboat\resources\views/livewire/hp/transaksi.blade.php ENDPATH**/ ?>