@extends('hp.template')

@section('title', 'Jadwal')

@section('content')
    @livewire('hp.jadwal-table')
@endsection
