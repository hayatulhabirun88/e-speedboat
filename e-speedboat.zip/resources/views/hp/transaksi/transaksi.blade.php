@extends('hp.template')

@section('content')
    @livewire('hp.transaksi')
@endsection
