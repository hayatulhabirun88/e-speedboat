@extends('hp.template')

@section('title', 'Pemesanan')

@section('content')
    @livewire('hp.pemesanan-table')
@endsection
